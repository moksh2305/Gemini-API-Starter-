package com.example.c020_assignment1;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_SPEECH_INPUT = 1;

    private RecyclerView recyclerView;
    private EditText editTextMessage;
    private ImageButton btnSend, btnVoice;
    private ChatAdapter adapter;
    private List<String> chatMessages;
    private GeminiApiService geminiApi;

    private TextView emptyStateTextView;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ✅ Match XML IDs
        recyclerView = findViewById(R.id.chatRecyclerView);
        editTextMessage = findViewById(R.id.promptEditText);
        btnSend = findViewById(R.id.sendButton);
        btnVoice = findViewById(R.id.micButton);
        emptyStateTextView = findViewById(R.id.emptyStateTextView);
        progressBar = findViewById(R.id.progressBar);

        chatMessages = new ArrayList<>();
        adapter = new ChatAdapter(chatMessages);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnSend.setOnClickListener(v -> sendMessage());
        btnVoice.setOnClickListener(v -> startVoiceInput());

        geminiApi = new GeminiApiService(BuildConfig.GEMINI_API_KEY);

        updateEmptyState();
    }

    private void sendMessage() {
        String msg = editTextMessage.getText().toString().trim();
        if (!msg.isEmpty()) {
            chatMessages.add("You: " + msg);
            adapter.notifyItemInserted(chatMessages.size() - 1);
            recyclerView.scrollToPosition(chatMessages.size() - 1);
            editTextMessage.setText("");
            updateEmptyState();

            progressBar.setVisibility(ProgressBar.VISIBLE);

            geminiApi.getResponse(msg, new GeminiApiService.GeminiCallback() {
                @Override
                public void onResponse(String response) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(ProgressBar.GONE);
                        chatMessages.add("Gemini: " + response);
                        adapter.notifyItemInserted(chatMessages.size() - 1);
                        recyclerView.scrollToPosition(chatMessages.size() - 1);
                        updateEmptyState();
                    });
                }

                @Override
                public void onError(String error) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(ProgressBar.GONE);
                        chatMessages.add("Error: " + error);
                        adapter.notifyItemInserted(chatMessages.size() - 1);
                        recyclerView.scrollToPosition(chatMessages.size() - 1);
                        updateEmptyState();
                    });
                }
            });
        }
    }

    private void startVoiceInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Voice input not supported", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SPEECH_INPUT && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (result != null && !result.isEmpty()) {
                editTextMessage.setText(result.get(0));
            }
        }
    }

    private void updateEmptyState() {
        if (chatMessages.isEmpty()) {
            emptyStateTextView.setVisibility(TextView.VISIBLE);
        } else {
            emptyStateTextView.setVisibility(TextView.GONE);
        }
    }
}
